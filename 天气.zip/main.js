var app = require('scripts/app');

app.getLocal();